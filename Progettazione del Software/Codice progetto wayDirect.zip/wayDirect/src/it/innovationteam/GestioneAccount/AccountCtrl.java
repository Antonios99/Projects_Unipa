/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.innovationteam.GestioneAccount;
import it.innovationteam.Entity.Cliente;
import it.innovationteam.Utility.DBMSAppBnd;
import it.innovationteam.Utility.Popup;
import it.innovationteam.Utility.Utils;
import java.nio.charset.Charset;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import javax.swing.JFrame;
/**
 *
 * @author gianvito
 */
public class AccountCtrl {
    
    private JFrame frame;
    private DBMSAppBnd dbmsBnd;
    private final short ETA_MINIMA = 14;
    private String codiceCasuale = "";
    private Cliente user;
    
    public AccountCtrl(JFrame fr) {
        this.dbmsBnd = new DBMSAppBnd();
        this.frame = fr; 
    }

    public AccountCtrl() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public SchermataImpostazioni impostazioni(){
        SchermataImpostazioni schermataImpostazioni = new SchermataImpostazioni();
        this.frame.dispose();
        return schermataImpostazioni;
    }
    public void controllaFormatoDatiLogin(String email, char[] pwd) {
        boolean v_email = this.validaEmail(email), v_pwd = v_pwd = this.validaPassword(pwd);
        String errore = "";
        if(v_email && v_pwd) { //fai login
            System.out.println("Autenticazione verso DBMSAppBnd");
            if(this.dbmsBnd.autenticazione(email, new String(pwd))){ //autenticazione OK
                SchermataPrincipaleCliente schermataPrincipale = new SchermataPrincipaleCliente();
                schermataPrincipale.setEmail(email);
                this.frame.dispose();
                return;
            }
            Popup.mostraErrore(this.frame, "Credenziali non valide, fai click su Recupera Password per ottenere una nuova password");
            return;
        }
        if(!v_email) errore += "Email non valida";
        if(!v_pwd)   errore += "Password non valida";
        if(!v_email && !v_pwd) errore = "Email non valida\nPassword non valida";
        if(!errore.isEmpty()) { //errore non vuoto
            Popup.mostraErrore(this.frame,errore);
        }
    }
    
    public boolean controllaFormatoDatiRegistrazione(String nome,String cognome,String sesso,Date dataNascita,String comuneNascita, String codiceFiscale,String tipologiaPatente, String numeroPatente,Date dataRilascioPatente,Date dataScadenzaPatente,String numeroCartaIdentita,String comuneRilascio,Date dataScadenzaCartaIdentita,String indirizzoResidenza,String cap,String numeroCartaCredito,Date dataScadenzaCartaCredito,String cvv,String email,String password,String confermaPassword,String cellulare, boolean consensoPrivacy, boolean consensoDispositivo){
        StringBuilder err = new StringBuilder();
        //controllare se i documenti sono scaduti
        if(dataNascita == null){
            err.append("\nData di nascita non valida");
        }
        else{
            LocalDate oggi = LocalDate.now();
            LocalDate nascita = Utils.dateToLocalDate(dataNascita);
            Period p = Period.between(nascita, oggi);
            if(p.getYears() < this.ETA_MINIMA){
                err.append("\nNon hai più di " + this.ETA_MINIMA + " anni");
                Popup.mostraErrore(this.frame, err.toString());
                return false;
            }
        }
        if(nome.isEmpty()) err.append("\nNome non valido");
        if(cognome.isEmpty()) err.append("\nCognome non valido");
        if(sesso.isEmpty()) err.append("\nSesso non valido");
        if(comuneNascita.isEmpty()) err.append("\nComune di nascita non valido");
        if(codiceFiscale.isEmpty() || codiceFiscale.length() < 16) err.append("\nCodice fiscale non valido");
        if(tipologiaPatente.equals("Nessuna patente")){
            if(numeroPatente.isEmpty()) err.append("\nNumero patente non valido");
            if(dataRilascioPatente == null || dataScadenzaPatente == null) err.append("\nData rilascio\scadenza patente non valide");
        }
        else if(dataRilascioPatente != null && dataScadenzaPatente != null && dataRilascioPatente.compareTo(dataScadenzaPatente) > 0) err.append("\nLa data di rilascio patente non può essere successiva alla data di scadenza");
        if(numeroCartaIdentita.isEmpty() || numeroCartaIdentita.length() != 9) err.append("\nNumero carta d'identità non valido");
        if(comuneRilascio.isEmpty()) err.append("\nComune di rilascio carta d'identità non valido");
        if(dataScadenzaCartaIdentita == null) err.append("\nData scadenza Carta d'Identità non valida");
        if(indirizzoResidenza.isEmpty()) err.append("\nIndirizzo di residenza non valido");
        if(cap.isEmpty() || cap.length() != 5) err.append("\nCAP non valido");
        if(numeroCartaCredito.isEmpty() || numeroCartaCredito.length() != 16) err.append("\nNumero carta di credito non valido");
        if(dataScadenzaCartaCredito == null) err.append("\nData scadenza carta di credito non valida");
        if(cvv.isEmpty() || cvv.length() != 3) err.append("\nCVV non valido");
        if(!Utils.checkEmail(email)) err.append("\nEmail non valida");
        if(!Utils.checkPassword(password)) err.append("\nPassword non valida, assicurati di rispettare i criteri minimi di sicurezza");
        if(!Utils.checkPassword(confermaPassword)) err.append("\nConferma Password non valida, assicurati di rispettare i criteri minimi di sicurezza");
        if(!confermaPassword.equals(password)) err.append("\nLa password di conferma non coincide con la password");
        if(!Utils.checkNumeroTelefono(cellulare)) err.append("\nCellulare non valido");
        if(!consensoPrivacy) err.append("\nConsenso privacy non selezionato!");
        if(!consensoDispositivo) err.append("\nDichiarazione di possesso del dispositivo mobile non effettuata!");
  
        if(err.isEmpty()){
            if(this.dbmsBnd.controllaEmail(email)){
                Popup.mostraErrore(this.frame, "L'email inserita risulta essere già registrata");
                return false;
            }
            this.user = new Cliente(nome,cognome,sesso,dataNascita,comuneNascita,codiceFiscale,tipologiaPatente,numeroPatente,dataRilascioPatente,dataScadenzaPatente,numeroCartaIdentita,comuneRilascio,dataScadenzaCartaIdentita,indirizzoResidenza,cap,numeroCartaCredito,dataScadenzaCartaCredito,cvv,email,password,cellulare);
            this.codiceCasuale = this.generaCodiceCasuale();
            this.inviaCodiceCasuale(email, this.codiceCasuale);
            CodiceConfermaBnd codiceConfermaBnd = new CodiceConfermaBnd();
            this.frame.dispose();
            if(this.verificaCodiceCasuale(this.codiceCasuale)){
                this.dbmsBnd.registraUtente(this.user);
                return true;
            }
        }
        else{
            Popup.mostraErrore(this.frame, err.toString());
        }
        return false;
    }
    public boolean verificaCodiceCasuale(String codice){
        return true;
    }
    public void resetPassword(String email){
        String passwordGenerata = "asdasdasd";
        /* 
        Generare la password dinamicamente quì dentro
        */
        this.dbmsBnd.setNuovaPassword(email, Utils.hashPassword(passwordGenerata));
    }
    public void aggiornaPassword(String email, String password){
        this.dbmsBnd.setNuovaPassword(email, Utils.hashPassword(password));
    }
    public HashMap<String,String> getProfilo(String email){
        return this.dbmsBnd.getInformazioniUtente(email);
    }
    private String generaCodiceCasuale(){
        byte[] array = new byte[7];
        new Random().nextBytes(array);
        return new String(array, Charset.forName("UTF-8"));
    }
    private void inviaCodiceCasuale(String email, String codice){
        System.err.println("Email inviata all'indirizzo " + email + " , Codice: " + codice);
    }
    private boolean validaEmail(String email){
        return Utils.checkEmail(email);
    }
    private boolean validaPassword(char[] psw) {
        return Utils.checkPassword(new String(psw));
    }
}
