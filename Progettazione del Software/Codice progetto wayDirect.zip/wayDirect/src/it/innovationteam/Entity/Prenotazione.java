/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.innovationteam.Entity;

import it.innovationteam.Utility.Utils;
import java.util.Date;

/**
 *
 * @author gianvito
 */
public class Prenotazione {
    private String emailCliente;
    private Date dataCreazionePrenotazione;
    private String indirizzoPartenza;
    private String indirizzoDestinazione;
    private Date dataInizioPrenotazione;
    private String parcheggioPartenza;
    private String parcheggioDestinazione;
    private Float importo;

    public String getEmailCliente() {
        return emailCliente;
    }

    public void setEmailCliente(String emailCliente) {
        this.emailCliente = emailCliente;
    }

    public String getDataCreazionePrenotazione() {
        return Utils.dateToString(dataCreazionePrenotazione);
    }

    public void setDataCreazionePrenotazione(Date dataCreazionePrenotazione) {
        this.dataCreazionePrenotazione = dataCreazionePrenotazione;
    }

    public String getIndirizzoPartenza() {
        return indirizzoPartenza;
    }

    public void setIndirizzoPartenza(String indirizzoPartenza) {
        this.indirizzoPartenza = indirizzoPartenza;
    }

    public String getIndirizzoDestinazione() {
        return indirizzoDestinazione;
    }

    public void setIndirizzoDestinazione(String indirizzoDestinazione) {
        this.indirizzoDestinazione = indirizzoDestinazione;
    }

    public String getDataInizioPrenotazione() {
        return Utils.dateToString(dataInizioPrenotazione);
    }

    public void setDataInizioPrenotazione(Date dataInizioPrenotazione) {
        this.dataInizioPrenotazione = dataInizioPrenotazione;
    }

    public String getParcheggioPartenza() {
        return parcheggioPartenza;
    }

    public void setParcheggioPartenza(String parcheggioPartenza) {
        this.parcheggioPartenza = parcheggioPartenza;
    }

    public String getParcheggioDestinazione() {
        return parcheggioDestinazione;
    }

    public void setParcheggioDestinazione(String parcheggioDestinazione) {
        this.parcheggioDestinazione = parcheggioDestinazione;
    }

    public Float getImporto() {
        return importo;
    }

    public void setImporto(Float importo) {
        this.importo = importo;
    }
}
