/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.innovationteam.Entity;

import it.innovationteam.Utility.Utils;
import java.util.Date;

/**
 *
 * @author gianvito
 */
public class Cliente {
    private String email;
    private String password;
    private String cellulare;
    private String nome;
    private String cognome;
    private String sesso;
    private Date dataNascita;
    private String comuneNascita;
    private String codiceFiscale;
    private String indirizzoResidenza;
    private String cap;
    private String tipologiaPatente;
    private String comuneRilascio;
    private String numeroCartaIdentita;
    private Date dataScadenzaPatente;
    private Date dataRilascioPatente;
    private String numeroPatente;
    private Date dataScadenzaCartaIdentita;
    private String numeroCartaCredito;
    private Date dataScadenzaCartaCredito;

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getCellulare() {
        return cellulare;
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getSesso() {
        return sesso;
    }

    public String getDataNascita() {
        return Utils.dateToString(this.dataNascita);
    }

    public String getComuneNascita() {
        return comuneNascita;
    }

    public String getCodiceFiscale() {
        return codiceFiscale;
    }

    public String getIndirizzoResidenza() {
        return indirizzoResidenza;
    }

    public String getCap() {
        return cap;
    }

    public String getTipologiaPatente() {
        return tipologiaPatente;
    }

    public String getComuneRilascio() {
        return comuneRilascio;
    }

    public String getNumeroCartaIdentita() {
        return numeroCartaIdentita;
    }

    public String getDataScadenzaPatente() {
        return Utils.dateToString(this.dataScadenzaPatente);
    }

    public String getDataRilascioPatente() {
        return Utils.dateToString(this.dataRilascioPatente);
    }

    public String getNumeroPatente() {
        return numeroPatente;
    }

    public String getDataScadenzaCartaIdentita() {
        return Utils.dateToString(this.dataScadenzaCartaIdentita);
    }

    public String getNumeroCartaCredito() {
        return numeroCartaCredito;
    }

    public String getDataScadenzaCartaCredito() {
        return Utils.dateToString(this.dataScadenzaCartaCredito);
    }

    public String getCvv() {
        return cvv;
    }
    private String cvv;
    
    public Cliente(String nome,String cognome,String sesso,Date dataNascita,String comuneNascita, String codiceFiscale,String tipologiaPatente, String numeroPatente,Date dataRilascioPatente,Date dataScadenzaPatente,String numeroCartaIdentita,String comuneRilascio,Date dataScadenzaCartaIdentita,String indirizzoResidenza,String cap,String numeroCartaCredito,Date dataScadenzaCartaCredito,String cvv,String email,String password,String cellulare){
        this.nome = nome;
        this.cognome = cognome;
        this.sesso = sesso;
        this.dataNascita = dataNascita;
        this.comuneNascita = comuneNascita;
        this.codiceFiscale = codiceFiscale;
        this.tipologiaPatente = tipologiaPatente;
        this.numeroPatente = numeroPatente;
        this.dataRilascioPatente = dataRilascioPatente;
        this.dataScadenzaPatente = dataScadenzaPatente;
        this.numeroCartaIdentita = numeroCartaIdentita;
        this.comuneRilascio = comuneRilascio;
        this.dataScadenzaCartaIdentita = dataScadenzaCartaIdentita;
        this.indirizzoResidenza = indirizzoResidenza;
        this.cap = cap;
        this.numeroCartaCredito = numeroCartaCredito;
        this.dataScadenzaCartaCredito = dataScadenzaCartaCredito;
        this.cvv = cvv;
        this.email = email;
        this.password = password;
        this.cellulare = cellulare;
    }
}
