/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.innovationteam.GestionePrenotazione;

import it.innovationteam.Utility.DBMSAppBnd;
import javax.swing.JFrame;

/**
 *
 * @author gianvito
 */
public class PrenotazioneCtrl {
    private JFrame frame;
    private DBMSAppBnd dbmsBnd;

    public PrenotazioneCtrl(JFrame fr) {
        this.dbmsBnd = new DBMSAppBnd();
        this.frame = fr; 
    }

    public void mostraData(){
        this.frame.dispose();
        DataBnd data = new DataBnd();
        
    }
    public void noleggioVeicolo(){
        IndirizziBnd ind = new IndirizziBnd();
        
    }
    public void nuovaPrenotazione(){
        SceltaPrenotazioneBnd sceltaPrenotazioneBnd = new SceltaPrenotazioneBnd();
    }
    
}
