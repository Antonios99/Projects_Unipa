/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.innovationteam.Utility;
import it.innovationteam.Entity.Cliente;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author gianvito
 */
public class DBMSAppBnd {
    private final String ip = "188.217.183.129";
    private final String port = "3306";
    private final String username = "waydirect";
    private final String password = "asd";
    private final String database = "wayDirect";
    private final String TABELLA_CLIENTE = "Cliente";

    public boolean autenticazione(String email, String pwd) {
        String dbPassword = "";
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://" + this.ip +":" + this.port + "/" + this.database, this.username, this.password);
            Statement stmt = conn.createStatement();
            String str = "SELECT * FROM " + this.TABELLA_CLIENTE + " WHERE Email = '" + email.toString() + "'";
            ResultSet rset = stmt.executeQuery(str);
            while(rset.next()){
                dbPassword = rset.getString("Password");
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        
        
        return Utils.hashPassword(pwd).equals(dbPassword);
    }
    public void registraUtente(Cliente user){
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://" + this.ip +":" + this.port + "/" + this.database, this.username, this.password);
            Statement stmt = conn.createStatement();
            String query = "INSERT INTO " + this.TABELLA_CLIENTE + "(idUtente,Email,Password,Nome,Cognome,ComuneDiNascita,CodiceFiscale,Sesso,DataDiNascita,IndirizzoDiResidenza,CAP,TipologiaPatente,NumeroPatente,DataRilascioPatente,DataScadenzaPatente,NumeroCartaIdentita,DataScadenzaCartaIdentita,ComuneRilascioCartaIdentita,NumeroCartaCredito,DataScadenzaCartaCredito,CVV,NumeroCellulare) VALUES(default,'" + user.getEmail() + "','" + Utils.hashPassword(user.getPassword()) + "','" + user.getNome() + "','" + user.getCognome() + "','" + user.getComuneNascita() + "','" + user.getCodiceFiscale() + "','" + user.getSesso() + "','" + user.getDataNascita() + "','" + user.getIndirizzoResidenza() + "','" + user.getCap() + "','" + user.getTipologiaPatente() + "','" + user.getNumeroPatente() + "','" + user.getDataRilascioPatente() + "','" + user.getDataScadenzaPatente() + "','" + user.getNumeroCartaIdentita() + "','" + user.getDataScadenzaCartaIdentita() + "','" + user.getComuneRilascio() + "','" + user.getNumeroCartaCredito() + "','" + user.getDataScadenzaCartaCredito() + "','" + user.getCvv() + "','" + user.getCellulare() + "')";
            stmt.executeUpdate(query);
            System.out.println(query);
        }
        catch (SQLException e) {
            e.printStackTrace();
        } 
    }
    public boolean controllaEmail(String email){
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://" + this.ip +":" + this.port + "/" + this.database, this.username, this.password);
            Statement stmt = conn.createStatement();
            String str = "SELECT * FROM "  + this.TABELLA_CLIENTE + " WHERE Email = '" + email + "'";
            ResultSet rset = stmt.executeQuery(str);
                return !rset.next() == false;
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return false;
    }
    public void setNuovaPassword(String email, String password){
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://" + this.ip +":" + this.port + "/" + this.database, this.username, this.password);
            Statement stmt = conn.createStatement();
            String str = "UPDATE " + this.TABELLA_CLIENTE + " SET Password = '" + password.toString() + "' WHERE Email = '" + email.toString() + "';";
            stmt.executeUpdate(str);
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }
     public HashMap<String,String> getInformazioniUtente(String email){
        HashMap<String,String> informazioni = new HashMap<String,String>();
        try{
            Connection conn = DriverManager.getConnection("jdbc:mysql://" + this.ip +":" + this.port + "/" + this.database, this.username, this.password);
            Statement stmt = conn.createStatement();
            String str = "SELECT * FROM " + this.TABELLA_CLIENTE + " WHERE Email = '" + email.toString() + "'";
            ResultSet rset = stmt.executeQuery(str);
            while(rset.next()){
                informazioni.put("nome", rset.getString("Nome"));
                informazioni.put("cognome", rset.getString("Cognome"));
                informazioni.put("email", rset.getString("Email"));
                informazioni.put("cellulare", rset.getString("NumeroCellulare"));
                informazioni.put("patente", rset.getString("TipologiaPatente"));
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return informazioni;
    }
}
