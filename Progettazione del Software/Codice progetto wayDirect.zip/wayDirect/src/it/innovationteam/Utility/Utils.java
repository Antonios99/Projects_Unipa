/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.innovationteam.Utility;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.commons.codec.digest.DigestUtils;
/**
 *
 * @author gianvito
 */
public class Utils {
    private static final short MIN_PASSWORD_LENGTH = 8;
    public static boolean checkEmail(String email){
        EmailValidator validator = EmailValidator.getInstance();
        return validator.isValid(email);
    }
    public static boolean checkPassword(String pwd){
        return pwd.length() >= 8;
    }
    public static boolean checkNumeroTelefono(String numero){
        return numero.matches("\\d+") && numero.length() <= 10 && numero.length() >= 8; //sono compresi tra 8 e 10?
    }
    public static LocalDate dateToLocalDate(Date dateToConvert) {
        return dateToConvert.toInstant()
          .atZone(ZoneId.systemDefault())
          .toLocalDate();
    }
    public static String hashPassword(String password){
        return DigestUtils.sha256Hex(password);
    }
    public static String dateToString(Date d){
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Europe/Paris"));
        cal.setTime(d);
        return cal.get(Calendar.YEAR) + "-" + cal.get(Calendar.MONTH) + "-" + cal.get(Calendar.DAY_OF_MONTH);
    }
}
        
