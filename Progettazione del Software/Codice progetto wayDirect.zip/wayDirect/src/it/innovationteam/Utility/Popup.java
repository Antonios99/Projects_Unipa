/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.innovationteam.Utility;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author gianvito
 */
public class Popup {
    
    public static void mostraConferma(JFrame frame, String title, String msg){
        JOptionPane.showMessageDialog(frame, msg, title, JOptionPane.PLAIN_MESSAGE);
    }
    public static void mostraErrore(JFrame frame, String msg){
        JOptionPane.showMessageDialog(frame, msg, "Errore", JOptionPane.ERROR_MESSAGE);
    }
}
